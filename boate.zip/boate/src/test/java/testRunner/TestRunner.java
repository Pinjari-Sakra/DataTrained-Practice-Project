package testRunner;

import org.junit.runner.RunWith;
import org.testng.annotations.AfterClass;

import com.cucumber.listener.Reporter;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import utilities.Utilities;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = "src/test/resources/Feature",
        glue = "setpDefination",
        plugin = {
                "pretty",
                "html:target/cucumber-reports/cucumber-pretty",
                "json:target/cucumber-reports/json-pretty"
             //  "com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-reports/cucumber-report.html",
               
        }
      


)
public class TestRunner extends Utilities  {
	
	 @AfterClass()
	    public static void writeExtentReport() {
	        Reporter.loadXMLConfig("./src/test/Resources/Configs/Extent-Config.xml");
	        Reporter.setSystemInfo("user", System.getProperty("user.name"));
	        Reporter.setSystemInfo("os", "windows OSX");
	        Reporter.setTestRunnerOutput("Sample test runner output message");
	        Reporter.addScenarioLog("Hello Cucumber");
	    }

}
