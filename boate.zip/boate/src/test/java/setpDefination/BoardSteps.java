package setpDefination;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import utilities.Utilities;


public class BoardSteps extends Utilities{
	

	 public static String getEndPoints;


@Given("^Board End Point \"([^\"]*)\"$")
public void board_End_Point(String testID) throws Throwable {
	 testcaseID = testID;
     testData = getEndPoints(testID);
//     System.out.println("testcaseID+" + testcaseID);
     loadPropertiesFile(propertiesFilePath);
     String baseURI = properties.getProperty("boards.url");
//     System.out.println("endpoint-" + apiEndpoint);
     apiEndpoint = baseURI + testData.getString(testcaseID + ".endpoint");
	  
}

@When("^User create new board with GET request$")
public void user_create_new_board_with_GET_request() throws Throwable {


	response = RestAssured.given()
            .auth().none()
        .log().all()
            .when()
            .get(apiEndpoint);
}

@Then("^response status code should be \"([^\"]*)\"$")
public void response_status_code_should_be(String arg1) throws Throwable {
	
	 System.out.println(response.prettyPrint());
	
}

@Then("^Board should be created successfully$")
public void board_should_be_created_successfully() throws Throwable {

	System.out.println("Response:" + response.prettyPrint());
	
}

///////////////////////////////////////////////

@When("User create new board with POST request")
public void user_create_new_board_with_post_request() {
	  response = RestAssured.given()
              .auth().none()
             
              .log().all()
              .when()
              .post(apiEndpoint);

	
}

@Then("Board should be displayed successfully")
public void board_should_be_displayed_successfully() {


	 System.out.println("Response:" + response.prettyPrint());
}

///////

@When("User create new board with PUT request")
public void user_create_new_board_with_put_request() {

	  response = RestAssured.given()
              .auth().none()
              .log().all()
             
              .when()
              .post(apiEndpoint);

  
	
}

@Then("Board Details should be displayed successfully")
public void board_details_should_be_displayed_successfully() {

	 System.out.println("Response:" + response.prettyPrint());
	
}

@When("Board details with GET request")
public void board_details_with_get_request() {

	 response = RestAssured.given()
             .auth().none()
             .log().all()
             .when()
             .get(apiEndpoint);
	
}

@Then("Details fetched successfully")
public void details_fetched_successfully() {

	 System.out.println("Response:" + response.prettyPrint());

	
	
}

}
