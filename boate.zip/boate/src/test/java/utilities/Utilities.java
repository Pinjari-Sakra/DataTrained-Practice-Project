package utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class Utilities {
	
	
	public static Properties properties = new Properties();
    public static Response response;
    public static JsonPath testData;
    public static String testcaseID;
    public static String apiEndpoint;
    public static String requestBody;
    public static String propertiesFilePath = "src/test/Resources/Testdata/Config.properties";

    public static String boardPath = "src/test/Resources/Testdata/Boards.json";

    public static JsonPath getEndPoints(String testCaseId) {
        if (testCaseId.startsWith("Board")) return new JsonPath(new File(boardPath));
        else return null;
    }
    public static void loadPropertiesFile(String filePath) throws IOException {
        try (FileInputStream fis = new FileInputStream(filePath)) {
            properties.load(fis);
        } catch (IOException e) {
            System.out.println("Properties file not found: " + filePath);
            throw e;
        }
    }


}
